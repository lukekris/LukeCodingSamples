package bankAccount;
import java.util.Scanner;

public class BankAccountMain {
	public static void main(String[] args) {
		System.out.println("Hello!");
		System.out.println("Welcome to the Bank Account Program!");
		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter your information below:");
		System.out.println("First Name: ");
		String firstName = scan.next();
		System.out.println("Last Name: ");
		String lastName = scan.next();
		System.out.println("Account ID: ");
		int accountID = scan.nextInt();
		CheckingAccount newAccount = new CheckingAccount(firstName, lastName, accountID);
		while(true) {
			System.out.println("\nSelect an option:");
			System.out.println("Enter 1 to Deposit Money");
			System.out.println("Enter 2 to Withdraw Money");
			System.out.println("Enter 3 to Display Account Summary");
			System.out.println("Enter 4 to Exit Program");
			System.out.print("Enter your option: ");
			int option = scan.nextInt();
			System.out.println("");
			if (option == 1) {
				System.out.println("Please enter deposit amount: ");
				double amount = scan.nextDouble();
				newAccount.deposit(amount);
			}
			else if (option == 2) {
				System.out.println("Please enter withdrawal amount: ");
				double amount = scan.nextDouble();
				newAccount.withdrawal(amount);
				newAccount.processWithdrawal();
			}
			else if (option == 3) {
				newAccount.displayAccount();
			}
			else if (option == 4) {
				System.out.println("Thank you and have a great day!");
				break;
			}
			else {
				System.out.println("Invalid Input. Please try again!");
			}
		}
		scan.close();
		
	}

}
