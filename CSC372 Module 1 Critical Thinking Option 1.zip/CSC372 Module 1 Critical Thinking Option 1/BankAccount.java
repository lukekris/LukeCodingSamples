package bankAccount;

public class BankAccount {
	String firstName;
	String lastName;
	int accountID;
	double balance;
	
	public BankAccount(String firstName, String lastName, int accountID) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.accountID = accountID;
		this.balance = 0;
	}

	public BankAccount() {
		balance = 0;
	}
	
	public void deposit(double depositMoney) {
		balance = balance + depositMoney;
	}
	
	public void withdrawal(double withdrawMoney) {
		balance = balance - withdrawMoney;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getAccountID() {
		return accountID;
	}

	public void setAccountID(int accountID) {
		this.accountID = accountID;
	}

	public double getBalance() {
		return balance;
	}
	
	public void accountSummary() {
		System.out.println("Account Information:");
		System.out.println("First Name: " + firstName);
		System.out.println("Last Name: " + lastName);
		System.out.println("Account ID: " + accountID);
		System.out.println("Balance: " + balance);
	}
}

class CheckingAccount extends BankAccount {
	double interestRate = 3;

	public CheckingAccount(String firstName, String lastName, int accountID) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.accountID = accountID;
		this.balance = 0;
	}

	public void processWithdrawal() {
		if (balance < 0) {
			balance = balance - 30;
			System.out.println("Balance: " + (balance));
			System.out.println("A $30 overdraft fee has been applied to your account due to a negative balance.");
		}
	}
	
	public void displayAccount() { 
		accountSummary();
		System.out.println("Interest Rate: " + interestRate + "%");
	}
}
